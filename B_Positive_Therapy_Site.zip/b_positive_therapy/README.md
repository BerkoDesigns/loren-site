# Loren Berkovics website: setup

## 1. Photos
`images/loren.jpg` is her photo. Optional: add `images/family.jpg` for the "person behind the therapist" section. Until it exists, a soft placeholder shows.

## 2. Google Sheet and script (blog and consultation form)
1. In Loren's Google account, create a new Google Sheet (name it "Loren website").
2. Extensions > Apps Script. Delete the sample code and paste in all of `Loren_Blog_Script.gs`.
3. At the top, replace `PUT_HER_EMAIL_HERE` with her email address.
4. Choose `setup` in the function dropdown and click Run. Approve the permissions (it needs the Sheet, Docs, and email). This builds the Posts, Requests, and How to post tabs.
5. Deploy > New deployment > Web app. Execute as: Me. Who has access: Anyone. Click Deploy and copy the Web app address.
6. In `site.js`, paste that address into `scriptUrl`.
7. Whenever the script code changes later: Deploy > Manage deployments > edit > New version.

## 3. Put the site online
Upload this folder to GitHub and connect it to Vercel (same as the shul boards). Then point her domain at it. The domain is still to be confirmed (B Positive Therapy).

## Notes
- The contact form can't read Google's reply, so it shows "sent" once the request leaves the browser. Test it once after setup and check that the email and the Requests row appear.
- Blog changes show up within about 5 minutes.
- Fees, insurance, her license number and her child's name are intentionally not on the site.
