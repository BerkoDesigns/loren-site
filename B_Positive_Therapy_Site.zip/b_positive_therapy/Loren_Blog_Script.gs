/**
 * Loren Berkovics website: blog and consultation requests.
 *
 * Put this script inside Loren's Google Sheet (Extensions > Apps Script),
 * run setup() once, then deploy as a Web app (see README).
 */

/* ---------- Settings ---------- */
const OWNER_EMAIL = 'PUT_HER_EMAIL_HERE';   // consultation requests are emailed here
const SITE_NAME = 'Loren Berkovics, LCSW';
const POSTS_SHEET = 'Posts';
const REQUESTS_SHEET = 'Requests';
const HOWTO_SHEET = 'How to post';
const CACHE_SECONDS = 300;                  // site shows changes within about 5 minutes

/* ---------- One-time setup ---------- */
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  /* Posts */
  let sh = ss.getSheetByName(POSTS_SHEET) || ss.insertSheet(POSTS_SHEET);
  sh.clear();
  sh.getRange(1, 1, 1, 5).setValues([['Title', 'Date', 'Short summary', 'Google Doc link', 'Status']])
    .setFontWeight('bold').setBackground('#B5654A').setFontColor('#FFF8F0');
  sh.setFrozenRows(1);
  sh.setColumnWidths(1, 1, 260); sh.setColumnWidths(2, 1, 110);
  sh.setColumnWidths(3, 1, 360); sh.setColumnWidths(4, 1, 300); sh.setColumnWidths(5, 1, 120);
  sh.getRange(2, 2, 500, 1).setNumberFormat('mmm d, yyyy');
  const rule = SpreadsheetApp.newDataValidation().requireValueInList(['Draft', 'Published'], true).setAllowInvalid(false).build();
  sh.getRange(2, 5, 500, 1).setDataValidation(rule).setHorizontalAlignment('center');
  const status = sh.getRange(2, 5, 500, 1);
  sh.setConditionalFormatRules([
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Published').setBackground('#CFE5CF').setFontColor('#1F4D2B').setRanges([status]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Draft').setBackground('#F3E7D6').setFontColor('#6B5A50').setRanges([status]).build()
  ]);
  sh.getRange(2, 1, 1, 5).setValues([['Welcome', new Date(), 'A sample post. Replace it with your own.', '', 'Draft']]);

  /* Requests */
  let rq = ss.getSheetByName(REQUESTS_SHEET) || ss.insertSheet(REQUESTS_SHEET);
  if (rq.getLastRow() === 0) {
    rq.getRange(1, 1, 1, 7).setValues([['Received', 'Name', 'Therapy for', 'Email', 'Phone', 'Best time', 'State']])
      .setFontWeight('bold').setBackground('#8A9A7B').setFontColor('#1F2A1B');
    rq.setFrozenRows(1);
    rq.setColumnWidths(1, 7, 150);
  }

  /* How to post */
  let hw = ss.getSheetByName(HOWTO_SHEET) || ss.insertSheet(HOWTO_SHEET);
  hw.clear();
  const lines = [
    ['How to post on your website'],
    [''],
    ['1. Write your article in a normal Google Doc. Use headings, bold, italics, bullet lists and links as you like.'],
    ['2. In the Posts tab, add a new row: the title, the date, a one or two sentence summary, and paste the link to your Doc.'],
    ['3. Leave Status on Draft while you are still working. Nothing shows on the website yet.'],
    ['4. When it is ready, change Status to Published. It appears on the website within about 5 minutes.'],
    ['5. To hide a post, change Status back to Draft. To fix a typo, edit the Doc and it updates on its own.'],
    [''],
    ['Notes'],
    ['The title for the website comes from the Posts tab, so you do not need to repeat it at the top of the Doc.'],
    ['Pictures and tables inside a Doc are not shown on the website yet. Text, headings, lists and links are.'],
    ['Your Docs can stay private. The website only shows posts marked Published.'],
    ['Consultation requests appear in the Requests tab and are also emailed to you.']
  ];
  hw.getRange(1, 1, lines.length, 1).setValues(lines);
  hw.setColumnWidth(1, 760);
  hw.getRange('A1').setFontSize(16).setFontWeight('bold');
  hw.getRange('A9').setFontWeight('bold');
  hw.getRange(1, 1, lines.length, 1).setWrap(true);

  const first = ss.getSheetByName('Sheet1');
  if (first && ss.getSheets().length > 1) ss.deleteSheet(first);
  ss.setActiveSheet(sh);
}

/* ---------- Web app entry points ---------- */
function doGet(e) {
  const action = e && e.parameter && e.parameter.action;
  if (action === 'posts') return json_(getPosts_());
  return json_({ ok: true });
}

function doPost(e) {
  try {
    const p = (e && e.parameter) || {};
    if (p.website) return json_({ ok: true });                       // spam trap
    const clean = k => String(p[k] || '').replace(/[\r\n]+/g, ' ').trim().slice(0, 200);
    const name = clean('name'), email = clean('email'), phone = clean('phone');
    if (!name || (!email && !phone)) return json_({ ok: false, error: 'missing' });
    const row = [new Date(), name, clean('for'), email, phone, clean('best_time'), clean('state')];

    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      SpreadsheetApp.getActiveSpreadsheet().getSheetByName(REQUESTS_SHEET).appendRow(row);
    } finally { lock.release(); }

    if (OWNER_EMAIL && OWNER_EMAIL.indexOf('@') > 0) {
      MailApp.sendEmail({
        to: OWNER_EMAIL,
        subject: 'New consultation request: ' + name,
        body: 'A new consultation request came in from your website.\n\n' +
          'Name: ' + name + '\nTherapy for: ' + clean('for') + '\nEmail: ' + (email || '(none)') +
          '\nPhone: ' + (phone || '(none)') + '\nBest time: ' + (clean('best_time') || '(none)') +
          '\nState: ' + clean('state') + '\n\nAll requests are also saved in the Requests tab of your Sheet.'
      });
    }
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: 'server' });
  }
}

/* ---------- Blog ---------- */
function getPosts_() {
  const cache = CacheService.getScriptCache();
  const hit = cache.get('posts');
  if (hit) return JSON.parse(hit);

  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(POSTS_SHEET);
  const rows = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, 5).getValues() : [];
  const tz = Session.getScriptTimeZone();
  const posts = [];

  rows.forEach(function (r) {
    const title = String(r[0] || '').trim();
    if (!title || String(r[4]).trim() !== 'Published') return;
    const date = r[1] instanceof Date ? Utilities.formatDate(r[1], tz, 'yyyy-MM-dd') : String(r[1] || '');
    const idMatch = String(r[3]).match(/[-\w]{25,}/);
    let html = '';
    if (idMatch) {
      try { html = docToHtml_(idMatch[0]); } catch (err) { html = '<p>This post is not available right now.</p>'; }
    }
    posts.push({
      id: slug_(title, date),
      title: title,
      date: date,
      summary: String(r[2] || '').trim(),
      html: html
    });
  });

  const out = { posts: posts };
  const text = JSON.stringify(out);
  if (text.length < 90000) cache.put('posts', text, CACHE_SECONDS);
  return out;
}

function slug_(title, date) {
  const s = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
  return (s || 'post') + '-' + date.replace(/-/g, '');
}

/* ---------- Google Doc to simple, safe HTML ---------- */
function docToHtml_(docId) {
  const body = DocumentApp.openById(docId).getBody();
  const out = [];
  let listTag = null;
  const closeList = function () { if (listTag) { out.push('</' + listTag + '>'); listTag = null; } };

  for (let i = 0; i < body.getNumChildren(); i++) {
    const el = body.getChild(i);
    const type = el.getType();

    if (type === DocumentApp.ElementType.PARAGRAPH) {
      closeList();
      const p = el.asParagraph();
      const inner = runs_(p.editAsText());
      if (!inner.replace(/<[^>]*>/g, '').trim()) continue;
      const h = p.getHeading();
      if (h === DocumentApp.ParagraphHeading.TITLE) continue;
      if (h === DocumentApp.ParagraphHeading.HEADING1) out.push('<h2>' + inner + '</h2>');
      else if (h === DocumentApp.ParagraphHeading.HEADING2 || h === DocumentApp.ParagraphHeading.HEADING3 ||
               h === DocumentApp.ParagraphHeading.HEADING4) out.push('<h3>' + inner + '</h3>');
      else out.push('<p>' + inner + '</p>');
    } else if (type === DocumentApp.ElementType.LIST_ITEM) {
      const li = el.asListItem();
      const g = li.getGlyphType();
      const ordered = [DocumentApp.GlyphType.NUMBER, DocumentApp.GlyphType.LATIN_UPPER, DocumentApp.GlyphType.LATIN_LOWER,
        DocumentApp.GlyphType.ROMAN_UPPER, DocumentApp.GlyphType.ROMAN_LOWER].indexOf(g) >= 0;
      const tag = ordered ? 'ol' : 'ul';
      if (listTag !== tag) { closeList(); out.push('<' + tag + '>'); listTag = tag; }
      out.push('<li>' + runs_(li.editAsText()) + '</li>');
    } else {
      closeList();
    }
  }
  closeList();
  return out.join('');
}

function runs_(textEl) {
  const text = textEl.getText();
  if (!text) return '';
  const idx = textEl.getTextAttributeIndices();
  let html = '';
  for (let k = 0; k < idx.length; k++) {
    const start = idx[k];
    const end = k + 1 < idx.length ? idx[k + 1] : text.length;
    let seg = esc_(text.substring(start, end)).replace(/\u000b/g, '<br>');
    if (!seg) continue;
    if (textEl.isBold(start)) seg = '<strong>' + seg + '</strong>';
    if (textEl.isItalic(start)) seg = '<em>' + seg + '</em>';
    const url = textEl.getLinkUrl(start);
    if (url && /^(https?:|mailto:)/i.test(url)) {
      seg = '<a href="' + esc_(url) + '" target="_blank" rel="noopener noreferrer">' + seg + '</a>';
    }
    html += seg;
  }
  return html;
}

function esc_(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
